
If you see this it means you already started the local WordPress environment
and your project is running at http://localhost:8000 already.

Your working directory is containing these files/folders:

your-name
├── README.md
├── docker-compose.yml
├── plugins-you-may-need
├── root
├── wordpress-docker-compose
└── wp-content

As you can see you have the `root` and `wp-content` folders, you will only need to work inside the `wp-content` folder, it is just a `wp-content` folder that you saw in all WordPress projects. So never touch the `root` folder unless it's needed.

Inside `plugins-you-may-need` there is a couple of WordPress plugins, it's CMB2, and the starter of Gutenberg Plugin,
move that folder to your `/wp-content/plugins` folder *only if you need it*.


That's it. Good luck!
